# Notes

- 고라니 (water deer)
- *field* notes
